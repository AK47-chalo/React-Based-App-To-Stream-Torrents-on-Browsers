const MovieTypes = [
    {
       "key":28,
       "name":"Hành Động"
    },
    {
       "key":12,
       "name":"Phiêu Lưu"
    },
    {
       "key":16,
       "name":"Hoạt Hình"
    },
    {
       "key":35,
       "name":"Hài"
    },
    {
       "key":80,
       "name":"Hình Sự"
    },
    {
       "key":99,
       "name":"Tài Liệu"
    },
    {
       "key":18,
       "name":"Chính Kịch"
    },
    {
       "key":10751,
       "name":"Gia Đình"
    },
    {
       "key":14,
       "name":"Giả Tưởng"
    },
    {
       "key":36,
       "name":"Lịch Sử"
    },
    {
       "key":27,
       "name":"Kinh Dị"
    },
    {
       "key":10402,
       "name":"Nhạc"
    },
    {
       "key":9648,
       "name":"Bí Ẩn"
    },
    {
       "key":10749,
       "name":"Lãng Mạn"
    },
    {
       "key":878,
       "name":"Khoa Học Viễn Tưởng"
    },
    {
       "key":10770,
       "name":"Chương Trình Truyền Hình"
    },
    {
       "key":53,
       "name":"Gây Cấn"
    },
    {
       "key":10752,
       "name":"Chiến Tranh"
    },
    {
       "key":37,
       "name":"Miền Tây"
    }
 ]
 export default MovieTypes;